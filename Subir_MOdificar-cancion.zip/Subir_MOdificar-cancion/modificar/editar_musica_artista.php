<?php
// Habilitar reporte de errores para depuración
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Depuración: Imprimir los datos recibidos del formulario
echo "<pre>";
print_r($_POST); // Muestra todos los datos enviados por el formulario
echo "</pre>";

// Configuración de la base de datos
$host = 'localhost';
$usuario = 'root';
$contraseña = '';
$nombre_bd = 'cosmiccatstudio';

// Crear conexión
$conn = new mysqli($host, $usuario, $contraseña, $nombre_bd);
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_musica = $_POST['id_musica'];
    $idartista = $_POST['idartista'];
    $tituloCancion = $_POST['titulo-cancion'];
    $genero = $_POST['genero'];
    $colaboradores = $_POST['colaboradores'];
    $letra = $_POST['letra'];

    // Verificar si hay una nueva foto representativa
    if (isset($_FILES['foto-representativa']) && $_FILES['foto-representativa']['error'] === UPLOAD_ERR_OK) {
        $fotoRepresentativa = file_get_contents($_FILES['foto-representativa']['tmp_name']);
        $sql = "UPDATE musica SET titulo = ?, genero = ?, colaboradores = ?, letra = ?, foto = ? WHERE id_musica = ? AND id_artista = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ssssssi', $tituloCancion, $genero, $colaboradores, $letra, $fotoRepresentativa, $id_musica, $idartista);
    } else {
        $sql = "UPDATE musica SET titulo = ?, genero = ?, colaboradores = ?, letra = ? WHERE id_musica = ? AND id_artista = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('sssssi', $tituloCancion, $genero, $colaboradores, $letra, $id_musica, $idartista);
    }

    // Ejecutar la consulta y verificar errores
    if ($stmt->execute()) {
        echo "Canción actualizada exitosamente.";
    } else {
        echo "Error al actualizar la canción: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
