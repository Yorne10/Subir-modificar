<?php
header('Content-Type: application/json');
error_reporting(E_ALL);

$host = 'localhost';
$usuario = 'root';
$contraseña = '';
$nombre_bd = 'cosmiccatstudio';

$conn = new mysqli($host, $usuario, $contraseña, $nombre_bd);
$conn->set_charset("utf8");

if ($conn->connect_error) {
    echo json_encode(["error" => "Conexión fallida: " . $conn->connect_error]);
    exit;
}

// Verificar si se especifican los parámetros id_musica y id_artista en la URL
if (isset($_GET['id_musica']) && isset($_GET['id_artista'])) {
    $id_musica = intval($_GET['id_musica']);
    $id_artista = intval($_GET['id_artista']);

    // Consulta para obtener los detalles de la canción
    $sql = "SELECT titulo, genero, colaboradores, letra, foto FROM musica WHERE id_musica = ? AND id_artista = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id_musica, $id_artista);
    $stmt->execute();
    $result = $stmt->get_result();
    $cancion = $result->fetch_assoc();

    if ($cancion) {
        // Convertir la imagen a base64 para ser utilizada en el frontend
        if (!empty($cancion['foto'])) {
            $cancion['foto'] = 'data:image/jpeg;base64,' . base64_encode($cancion['foto']);
        } else {
            $cancion['foto'] = null; // En caso de que no haya foto
        }
        
        // Enviar los datos de la canción en formato JSON
        echo json_encode($cancion);
    } else {
        echo json_encode(["error" => "Canción no encontrada."]);
    }
} else {
    echo json_encode(["error" => "ID de canción o artista no especificado."]);
}

$conn->close();
?>
